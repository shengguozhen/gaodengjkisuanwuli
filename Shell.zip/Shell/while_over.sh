#!/bin/sh

echo "Please input a string, type over to finsh: "
while [ "$variable" != "over" ]
do
  read variable
  echo "Your input text is $variable."
done

