#!/bin/sh

counter=0
until [ $counter -ge 10 ]
do
   counter=`expr $counter + 1`
   echo $counter
done
echo "End"

