#!/bin/bash
usage(){
        echo "Usage: $0 filename"
        exit 1
}
is_file_exist(){
        f="$1"
        [ -f "$f" ] && return 0 || return 1
}

[ $# -eq 0 ] && usage

if  ( is_file_exist "$1" ); then
        echo "File found"
else
        echo "File not found"
fi

