#!/bin/sh

read -p "Please input a integer number: " x
declare -i i=1
declare -i sum=0
for ((i=1;i<=x;i++))
do
   sum=`expr $sum+$i`
done
echo $sum

