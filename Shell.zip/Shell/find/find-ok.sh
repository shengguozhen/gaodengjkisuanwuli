find . -name "*.sh" -ok cp {} test/test_find_ok \;
