find ../ -name "*.sh" -print -exec grep "input" {} \;
