#!/bin/sh
i=0; n=5
 while [ $i -lt $n ] ; do
     echo "Please input five strings …"
     read array[$i]
     echo "The element $i is: " ${array[$i]}
     i=`expr $i + 1`
 done

echo "The input strings are:"
for i in ${array[*]}
do
	echo $i
done
