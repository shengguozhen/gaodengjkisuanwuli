#!/bin/sh
echo "Please input an integer(0 -> end): "
read variable
while [ "$variable" -ne 0 ]
do
   if [ $variable -gt 30 ]; then
      echo "Input number is larger 30, script will exit!"
      break
   fi
   for ((i=1;i<="$variable";i++))
   do
      echo "Your input number is $variable."
   done
   read variable
done

