#!/bin/bash
cd                          #切换到用户根目录，因为.bash_profile在根目录下
.  .bash_profile        #配置用户的命令行环境
date                       #显示日期命令
who                       #显示当前的登录用户

