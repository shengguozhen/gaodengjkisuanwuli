echo $PATH
date

