#!/bin/sh

users=`cut -d ':' -f 1 /etc/passwd`
for username in $users
do
  echo -e "$users \n"
done

