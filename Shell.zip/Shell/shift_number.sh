#!/bin/sh
echo 'Total parameter number is ==> $#'
echo "Total parameter number is ==> $#"
echo "Your whole parameter is ==> '$@'"
echo "$0"
echo "$1"
shift
echo "Total parameter number is ==> $#"
echo "Your whole parameter is ==> '$@'"
shift 3
echo "Total parameter number is ==> $#"
echo "Your whole parameter is ==> '$@'"
