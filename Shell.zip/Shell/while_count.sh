#!/bin/sh

counter=0
while [ $counter -lt 10 ]
do
   counter=`expr $counter + 1`
   echo $counter
done
echo "End"

