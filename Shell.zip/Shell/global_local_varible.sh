#!/bin/bash

# gloabal x, y, z
x=100
y=200
z=300
echo "x: $x, y: $y, z: $z"

math(){
  # local variable x and y
  local x=$1
  local y=$2
  echo $(($x + $y + $z))
}

echo -n "execute math 10 20 = "
math 10 20

# x and y are not modified by math()
echo "x: $x, y: $y, z: $z"

