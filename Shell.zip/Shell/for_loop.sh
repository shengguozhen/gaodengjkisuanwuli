#!/bin/sh
for var
do
   echo $var
done

